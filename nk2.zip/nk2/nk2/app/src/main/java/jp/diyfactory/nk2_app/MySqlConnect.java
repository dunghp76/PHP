package jp.diyfactory.nk2_app;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.*;

import static android.content.ContentValues.TAG;

public class MySqlConnect extends AsyncTask<String, String, Integer> {
    private AsyncTaskCallbacks callback = null;
    ProgressDialog dialog;
    Context context;

    public MySqlConnect(Context context, AsyncTaskCallbacks callback){
        this.context = context;
        this.callback = callback;
    }
    @Override
    protected void onPreExecute() {
        Log.d(TAG, "onPreExecute");
        dialog = new ProgressDialog(context);
        dialog.setTitle("少々お待ちください。");
        dialog.setMessage("データローディング...");
        dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        dialog.setMax(100);
        dialog.setProgress(0);
        dialog.show();
    }
    @Override
    protected Integer doInBackground(String... inPara) {
        int iResult = 1;
        SharedPreferences data = context.getSharedPreferences("DataSave", context.MODE_PRIVATE);
        String productCode = data.getString("ProductCode","" );
        String sJan = String.format("%13s", inPara[1]).replace(" ","0");
        if(productCode.trim().equals("")) return 0;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://mysql-test-gufu.cqnq0j3be4gt.ap-northeast-1.rds.amazonaws.com:3306","daito_db","ofe!vb8w5q8)p4ppl1j0(gc!jrsl");
            conn.setAutoCommit(false);
            Statement stmt=conn.createStatement();
            String sql="UPDATE nk2.mst_product_stock AS a SET a.shelf_no = \'" + inPara[0] + "\', a.is_temp_shelf = 0 WHERE a.product_code = \'" +  productCode.trim() + "\'";
            String sqlin="INSERT INTO nk2.dt_product_tana ( product_code, shelf_no, in_ope_cd, up_ope_cd) VALUES ( \'" + productCode.trim() + "\', \'" +  inPara[0] + "\', \'DEV00001\', \'DEV00001\')";
            try {
                int rs = stmt.executeUpdate(sql);
                int rsin = stmt.executeUpdate(sqlin);
                if (rs < 1 || rsin < 1) {
                    conn.rollback();
                    iResult = -1;
                }else{
                    conn.commit();
                    iResult = 1;
                }
            }catch (SQLException e){
                conn.rollback();
                iResult = -1;
            }
            stmt.close();
            conn.close();
        }catch(Exception e){
            e.getMessage();
            iResult = -1;
        }
        return iResult;
    }
    /**
     * バックグランド処理が完了し、UIスレッドに反映する
     */
    @Override
    protected void onPostExecute(Integer result) {
        SharedPreferences data = context.getSharedPreferences("DataSave", context.MODE_PRIVATE);
        SharedPreferences.Editor editor = data.edit();
        editor.putInt("CallBack", result);
        editor.apply();
        dialog.dismiss();
        callback.onTaskFinished();
    }
}
