package jp.diyfactory.nk2_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class GoodsReceiver extends AppCompatActivity implements TextWatcher, View.OnClickListener, AsyncTaskCallbacks {
    EditText edtJan;
    EditText edtScanNum;
    EditText edtNewShelfNo;
    TextView txtSupplier;
    TextView txtMakerCode;
    TextView txtNowShelfNo;
    TextView txtNowStockNum;
    TextView txtNewShelfLbl;
    TextView txtPlanStockNum;
    Button btnReceived;
    Button btnCancel;
    MediaPlayer mpDoing;
    MediaPlayer mpError;
    MediaPlayer mpFinish;
    int iScanCount = 0;
    int iJanLength = 0;
    int iPlanNum = 0;
    int iRealNum = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receiver);
        edtJan = findViewById(R.id.txtJan);
        edtScanNum = findViewById(R.id.edtScanQuantiy);
        edtNewShelfNo = findViewById(R.id.txeNewShelfno);
        txtSupplier = findViewById(R.id.txvSupName);
        txtMakerCode = findViewById(R.id.txvMakerCode);
        txtNowShelfNo = findViewById(R.id.txvNowShelfNo);
        txtNowStockNum = findViewById(R.id.txvQuantiy);
        txtPlanStockNum = findViewById(R.id.txvPlanQuantiy);
        txtNewShelfLbl = findViewById(R.id.tvNewShelf);
        btnReceived = findViewById(R.id.btnUpdate);
        btnCancel = findViewById(R.id.btnCancel);
        edtNewShelfNo.setShowSoftInputOnFocus(false);
        edtScanNum.setShowSoftInputOnFocus(false);
        edtJan.setShowSoftInputOnFocus(false);
        edtNewShelfNo.setEnabled(false);
        txtNewShelfLbl.setTextColor(Color.rgb(127, 127, 120));
        edtJan.addTextChangedListener(this);
        edtScanNum.addTextChangedListener(this);
        edtNewShelfNo.addTextChangedListener(this);
        btnReceived.setOnClickListener(this);
        btnReceived.setEnabled(false);
        btnCancel.setOnClickListener(this);
        edtJan.setShowSoftInputOnFocus(false);
        edtJan.requestFocus();
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        mpFinish=MediaPlayer.create(getApplicationContext(),R.raw.in_kanryou);
        mpDoing=MediaPlayer.create(getApplicationContext(),R.raw.doing);
        mpError=MediaPlayer.create(getApplicationContext(),R.raw.error1);
    }

    public void onClick(View view){
        if(view == btnReceived) {
            String sJan = edtJan.getText().toString();
            String iProcessStatus = "";
            String sNewShelfNo = edtNewShelfNo.getText().toString();
            if(iScanCount + iRealNum < iPlanNum ){
                iProcessStatus = "1";
            }else{
                iProcessStatus = "2";
            }
            String sScanCount = String.valueOf(iScanCount);
            new MySqlReceiveProcess(this,this).execute(sScanCount, iProcessStatus, sJan, sNewShelfNo);
            edtJan.setText("");
            txtSupplier.setText("");
            txtMakerCode.setText("");
            txtNowShelfNo.setText("");
            txtNowStockNum.setText("");
            txtPlanStockNum.setText("");
            edtScanNum.setText("");
            edtNewShelfNo.setText("");
            edtNewShelfNo.setEnabled(false);
            txtNewShelfLbl.setTextColor(Color.rgb(127, 127, 120));
            btnReceived.setEnabled(false);
            edtJan.requestFocus();

        }
        else if(view == btnCancel) {
            edtJan.setText("");
            txtSupplier.setText("");
            txtMakerCode.setText("");
            txtNowShelfNo.setText("");
            txtNowStockNum.setText("");
            txtPlanStockNum.setText("");
            edtScanNum.setText("");
            edtNewShelfNo.setText("");
            edtNewShelfNo.setEnabled(false);
            txtNewShelfLbl.setTextColor(Color.rgb(127, 127, 120));
            btnReceived.setEnabled(false);
            edtJan.requestFocus();

        }
    }

    @Override
    public void onTaskFinished() {
        // TODO Auto-generated method stub
        SharedPreferences data = this.getSharedPreferences("DataSave", this.MODE_PRIVATE);
        int iResult = data.getInt("CallBack",0 );
        iRealNum = data.getInt("RealQua",0);
        if(iResult < 0){
            mpError.start();
            new AlertDialog.Builder(this)
                    .setTitle("警告")
                    .setMessage("この商品が入荷できません。")
                    .setCancelable(false)
                    .setPositiveButton("はい", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    }).show();
            edtJan.setText("");
            txtSupplier.setText("");
            txtMakerCode.setText("");
            txtNowShelfNo.setText("");
            txtNowStockNum.setText("");
            txtPlanStockNum.setText("");
            edtScanNum.setText("");
            edtNewShelfNo.setText("");
            btnReceived.setEnabled(false);
            edtJan.requestFocus();
        }else if(iResult == 0){
            int iNowStockNum = 0;
            String stockNum = txtNowStockNum.getText().toString();
            if(stockNum.length() > 0) {
                iNowStockNum = Integer.parseInt(stockNum);
            }
            if(iNowStockNum <= 0){
                edtNewShelfNo.setEnabled(true);
                txtNewShelfLbl.setTextColor(Color.rgb(127, 0, 0));
            }
            iScanCount++;
            edtScanNum.setText(String.valueOf(iScanCount));
            btnReceived.setEnabled(true);
            mpDoing.start();
        }
    }

    @Override
    public void onTaskCancelled() {
        // TODO Auto-generated method stub

    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        //edtScanNum.setText("");
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }

    @Override
    public void afterTextChanged(Editable s) {
        // テキスト変更後に変更されたテキストを取り出す
        String inputA = s.toString();
        if(edtJan.isFocused()){
            String sJan = edtJan.getText().toString();
            iJanLength = sJan.length();
            if(iJanLength > 0) {
                if(iJanLength < 13){
                    sJan = String.format("%13s", sJan).replace(" ","0");
                    edtJan.setText(sJan);
                }
                new MySqlSelectReceiveData(this, this, txtSupplier, txtMakerCode,
                        txtNowShelfNo, txtPlanStockNum, txtNowStockNum).execute(sJan);
                iScanCount = 0;
                edtScanNum.requestFocus();
            }
        }else if(edtScanNum.isFocused()){
            if (mpDoing.isPlaying()) {
                mpDoing.stop();
            }
            if (mpFinish.isPlaying()) {
                mpFinish.stop();
            }
            String sJan = edtJan.getText().toString();
            String sScanNum = edtScanNum.getText().toString();
            if(sScanNum.length() > 4) {
                sScanNum = sScanNum.substring(0, iJanLength);
                sScanNum = String.format("%13s", sScanNum).replace(" ", "0");
                if (sJan.trim().equals(sScanNum)) {
                    iScanCount++;
                    iPlanNum = Integer.parseInt(txtPlanStockNum.getText().toString());
                    edtScanNum.setText(String.valueOf(iScanCount));
                    if (iScanCount == (iPlanNum )) {
                        mpFinish.start();
                        edtNewShelfNo.requestFocus();
                        btnReceived.requestFocus();
                    } else if(iScanCount > (iPlanNum)){

                    }else{
                        mpDoing.start();
                    }
                }
            }
        }
    }
}
