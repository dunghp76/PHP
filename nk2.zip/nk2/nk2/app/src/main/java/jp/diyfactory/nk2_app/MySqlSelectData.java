package jp.diyfactory.nk2_app;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import static android.content.ContentValues.TAG;

public class MySqlSelectData extends AsyncTask<String, String, ProductInfo> {
    private AsyncTaskCallbacks callback = null;
    ProgressDialog dialog;
    private Context context;
    private TextView txtMC;
    private TextView txtSN;
    private TextView txtQA;
    private String sProCode;

    public MySqlSelectData(Context context, AsyncTaskCallbacks callback, TextView makerCode, TextView shelfNo, TextView quantity, String proCode){
        this.callback = callback;
        this.context = context;
        this.txtMC = makerCode;
        this.txtSN = shelfNo;
        this.txtQA = quantity;
        this.sProCode = proCode;
    }
    @Override
    protected void onPreExecute() {
        Log.d(TAG, "onPreExecute");
        dialog = new ProgressDialog(context);
        dialog.setTitle("少々お待ちください。");
        dialog.setMessage("データローディング...");
        dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        dialog.setMax(100);
        dialog.setProgress(0);
        dialog.show();
    }
    @Override
    protected ProductInfo doInBackground(String... inPara) {
        int iResult = 1;
        ProductInfo proInfo = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn= DriverManager.getConnection("jdbc:mysql://mysql-test-gufu.cqnq0j3be4gt.ap-northeast-1.rds.amazonaws.com:3306","daito_db","ofe!vb8w5q8)p4ppl1j0(gc!jrsl");
            Statement stmt=conn.createStatement();
            String sql="SELECT a.product_code, a.maker_code, a.shelf_no, a.stock_num FROM nk2.mst_product_stock AS a WHERE a.product_jan =\'" + inPara[0] + "\'";
            ResultSet rs=stmt.executeQuery(sql);
            if(rs.next()) {
                proInfo = new ProductInfo(rs.getString("product_code"),
                        rs.getString("maker_code"),
                        rs.getString("shelf_no"), rs.getInt("stock_num"));
            }else{
                proInfo = null;
            }
            rs.close();
            stmt.close();
            conn.close();
        }catch(Exception e){
            e.getMessage();
            proInfo = null;
        }
        return proInfo;
    }
    /**
     * バックグランド処理が完了し、UIスレッドに反映する
     */
    @Override
    protected void onPostExecute(ProductInfo proInfo) {
        //this.txtPC.setText(proInfo.getsProductCode());
        if(proInfo != null) {
            String shelfNo = proInfo.getsShelfNo();
            String quantity = String.valueOf(proInfo.getiQuantity());
            String makerCode = proInfo.getsMakerCode();
            String productCode = proInfo.getsProductCode();
            this.txtMC.setText(makerCode.toString());
            this.txtSN.setText(shelfNo.toString());
            this.txtQA.setText(quantity.toString());
            this.sProCode = proInfo.getsProductCode();
            SharedPreferences data = context.getSharedPreferences("DataSave", context.MODE_PRIVATE);
            SharedPreferences.Editor editor = data.edit();
            editor.putString("ProductCode", productCode.toString());
            editor.putInt("CallBack", 0);
            editor.apply();
        }else{
            SharedPreferences data = context.getSharedPreferences("DataSave", context.MODE_PRIVATE);
            SharedPreferences.Editor editor = data.edit();
            editor.putInt("CallBack", -1);
            editor.apply();
        }
        //Log.d(TAG, "onPostExecute - " + proInfo);
        dialog.dismiss();
        callback.onTaskFinished();
    }

    @Override
    protected void onCancelled() {
        // TODO Auto-generated method stub
        Log.v("AsyncTask", "onCancelled");
        callback.onTaskCancelled();
    }
}
