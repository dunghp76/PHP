package jp.diyfactory.nk2_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements TextWatcher, View.OnClickListener, AsyncTaskCallbacks {
    static  String sProductCode = "";
    EditText txtJan;
    EditText txtNewShelfNo;
    TextView txvOldShelfNo;
    TextView txvQuantity;
    TextView txvMakerCode;
    Button   btnUpdate;
    Button   btnCancel;
    Boolean  bControl = false;
    MediaPlayer mpError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtJan = findViewById(R.id.txtJan);
        txtNewShelfNo = findViewById(R.id.txeNewShelfno);
        txvOldShelfNo = findViewById(R.id.txvNowShelfNo);
        txvQuantity = findViewById(R.id.txvQuantiy);
        txvMakerCode = findViewById(R.id.txvMakerCode);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnCancel = findViewById(R.id.btnCancel);
        txtJan.addTextChangedListener(this);
        txtNewShelfNo.addTextChangedListener(this);
        txtNewShelfNo.setShowSoftInputOnFocus(false);
        btnUpdate.setOnClickListener(this);
        btnUpdate.setEnabled(false);
        btnCancel.setOnClickListener(this);
        txtJan.setShowSoftInputOnFocus(false);
        txtJan.requestFocus();
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        mpError=MediaPlayer.create(getApplicationContext(),R.raw.error1);
    }

    public void onClick(View view){
        if(view == btnUpdate) {
            String sJan = txtJan.getText().toString();
            if(!sJan.trim().equals("")) {
                String sShelfNo = txtNewShelfNo.getText().toString();
                new MySqlConnect(this, this).execute(sShelfNo, sJan, sProductCode);
            }
            txtJan.setText("");
            txtNewShelfNo.setText("");
            txvOldShelfNo.setText("");
            txvQuantity.setText("");
            txvMakerCode.setText("");
            txtJan.requestFocus();
            btnUpdate.setEnabled(false);
        }
        else if(view == btnCancel) {
            bControl = true;
            txtJan.setText("");
            txtNewShelfNo.setText("");
            txvOldShelfNo.setText("");
            txvQuantity.setText("");
            txvMakerCode.setText("");
            btnUpdate.setEnabled(false);
            txtJan.requestFocus();

        }
    }

    @Override
    public void onTaskFinished() {
        // TODO Auto-generated method stub
        SharedPreferences data = this.getSharedPreferences("DataSave", this.MODE_PRIVATE);
        int iResult = data.getInt("CallBack",0 );
        if(iResult < 0){
            new AlertDialog.Builder(this)
                    .setTitle("警告")
                    .setMessage("棚番変更できませんでした。")
                    .setCancelable(false)
                    .setPositiveButton("はい", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    }).show();
            mpError.start();
            bControl = true;
            txtJan.setText("");
            txtNewShelfNo.setText("");
            txvOldShelfNo.setText("");
            txvQuantity.setText("");
            txvMakerCode.setText("");
            txtJan.requestFocus();
        }
    }

    @Override
    public void onTaskCancelled() {
        // TODO Auto-generated method stub

    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        //txtJan.setText("");
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }

    @Override
    public void afterTextChanged(Editable s) {
        // テキスト変更後に変更されたテキストを取り出す
        String inputA = s.toString();
        if(txtJan.isFocused()){
            String sJan = txtJan.getText().toString();
            if(!sJan.trim().equals("")) {
                sJan = String.format("%13s", sJan).replace(" ","0");
                new MySqlSelectData(this, this,txvMakerCode, txvOldShelfNo, txvQuantity, sProductCode).execute(sJan);
                txtNewShelfNo.requestFocus();
            }
        }else if(txtNewShelfNo.isFocused()){
            String sJan = txtJan.getText().toString();
            String sShelfNo = txtNewShelfNo.getText().toString();
            if(sJan.trim().length() > 0 && sShelfNo.trim().length() > 0){
                btnUpdate.setEnabled(true);
                btnUpdate.requestFocus();
            }
        }
    }
}
