package jp.diyfactory.nk2_app;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.*;
import java.util.Calendar;

import static android.content.ContentValues.TAG;

public class MySqlReceiveProcess extends AsyncTask<String, String, Integer> {
    private AsyncTaskCallbacks callback = null;
    ProgressDialog dialog;
    Context context;

    public MySqlReceiveProcess(Context context,AsyncTaskCallbacks callback){
        this.context = context;
        this.callback = callback;
    }
    @Override
    protected void onPreExecute() {
        Log.d(TAG, "onPreExecute");
        dialog = new ProgressDialog(context);
        dialog.setTitle("少々お待ちください。");
        dialog.setMessage("データローディング...");
        dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        dialog.setMax(100);
        dialog.setProgress(0);
        dialog.show();
    }
    @Override
    protected Integer doInBackground(String... inPara) {
        int iResult = 1;
        SharedPreferences data = context.getSharedPreferences("DataSave", context.MODE_PRIVATE);
        String productCode = data.getString("ProductCode","" );
        String requestNum = data.getString("RequestNum","" );
        String requestLine = data.getString("RequestLine","" );
        int iSupID = data.getInt("SupplierID",0 );
        int istockNum = data.getInt("StockNum", 0);
        int iNewStockNum = istockNum + Integer.valueOf(inPara[0]);
        if(productCode.trim().equals("")) return 0;
        String sJan = String.format("%13s", inPara[2]).replace(" ","0");
        Date date = new Date(System.currentTimeMillis());
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://mysql-test-gufu.cqnq0j3be4gt.ap-northeast-1.rds.amazonaws.com:3306","daito_db","ofe!vb8w5q8)p4ppl1j0(gc!jrsl");
            conn.setAutoCommit(false);
            Statement stmt=conn.createStatement();
            String sqlModel="UPDATE nk2.dt_request_model AS a " +
                    "SET a.quantity = a.quantity + " + inPara[0]+ ", " +
                    "a.real_receive_num = a.real_receive_num  + " + inPara[0] + ", " +
                    "a.process_status =  " + inPara[1] +
                    " WHERE a.request_num =  \'" + requestNum + "\' " +
                    "AND a.request_line_num = \'" + requestLine + "\' " +
                    "AND a.process_status < 2 ";

            String sqlStock = "UPDATE nk2.mst_product_stock AS b " +
                    "SET b.stock_num = b.stock_num + \'" + inPara[0] + "\'," +
                    "b.received_num = b.received_num + \'" + inPara[0] + "\'," +
                    "b.receive_plan_num = b.receive_plan_num - \'" + inPara[0] + "\' ";
            String sqlStock_ShelfNo = ",b.shelf_no = \'" + inPara[3] + "\' ";
            String sqlStockWhere = "WHERE b.product_code ="  + "\'" + productCode + "\'" ;
            if(inPara[3].length() > 0 ) {
                sqlStock = sqlStock + sqlStock_ShelfNo + sqlStockWhere;
            }else{
                sqlStock = sqlStock + sqlStockWhere;
            }

            String sqlLedger = "INSERT INTO nk2.dt_receipt_ledger ( line_index, request_num, request_line_num, " +
                    "product_code, product_jan, contents, process_date, changed_quantity, remain_quantity_detail, " +
                    "remain_quantity, process_type, in_date, in_ope_cd, up_date, up_ope_cd) " +
                    " VALUES ( 1, \'" + requestNum + "\', \'" + requestLine + "\', \'" + productCode + "\', \'" +
                    sJan + "\', \'" + "仕入処理　" + iSupID + "\', \'" + date +  "\', \'" + inPara[0] +  "\', \'0\', \'"  +
                    iNewStockNum +  "\',  \'1\', \'" +  date + "\', \'DEV00001\', \'" + date +  "\', \'DEV00001\')" ;
            try {

                int rsModel = stmt.executeUpdate(sqlModel);
                int rsStock = stmt.executeUpdate(sqlStock);
                int rsLedger = stmt.executeUpdate(sqlLedger);
                if(rsModel < 1 || rsStock < 1 || rsLedger < 1){
                    conn.rollback();
                    iResult = -1;
                }else{
                    conn.commit();
                    iResult = 1;
                }
            }catch (SQLException e){
                conn.rollback();
                iResult = -1;
            }
            stmt.close();
            conn.close();
        }catch(Exception e){

            e.getMessage();
            iResult = -1;
        }
        return iResult;
    }
    /**
     * バックグランド処理が完了し、UIスレッドに反映する
     */
    @Override
    protected void onPostExecute(Integer result) {
        SharedPreferences data = context.getSharedPreferences("DataSave", context.MODE_PRIVATE);
        SharedPreferences.Editor editor = data.edit();
        editor.putInt("CallBack", result);
        editor.apply();
        dialog.dismiss();
        callback.onTaskFinished();
    }
}
