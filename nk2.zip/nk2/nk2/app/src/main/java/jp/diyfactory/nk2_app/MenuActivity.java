package jp.diyfactory.nk2_app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity implements View.OnClickListener{
    Button btnChangeShelfNo;
    Button btnReceiveProcess;
    Button btnJPSize;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu);
        btnChangeShelfNo = findViewById(R.id.btnShelfChange);
        btnReceiveProcess = findViewById(R.id.btnScanJan);
        btnJPSize = findViewById(R.id.btnJPSize);
        btnChangeShelfNo.setOnClickListener(this);
        btnReceiveProcess.setOnClickListener(this);
        btnJPSize.setOnClickListener(this);
        btnChangeShelfNo.requestFocus();
    }

    public void onClick(View view){
        if(view == btnChangeShelfNo) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        else if(view == btnReceiveProcess) {
            Intent intent = new Intent(this, GoodsReceiver.class);
            startActivity(intent);
        }
        else if(view == btnJPSize) {
            Intent intent = new Intent(this, JPSizeRegister.class);
            startActivity(intent);
        }
    }
}
