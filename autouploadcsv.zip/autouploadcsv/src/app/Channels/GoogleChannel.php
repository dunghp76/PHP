<?php
/**
 * Channel google
 *
 * @package    App\Channels
 * @subpackage GoogleChannel
 * @copyright  Copyright (c) 2019 Daito! Corporation. All Rights Reserved.
 * @author     lam.vinh<eagle_vn@monotos.biz>
 */
namespace App\Channels;

use GuzzleHttp\Client;
use Illuminate\Support\Str;
use GuzzleHttp\Psr7\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Notifications\Notification;

class GoogleChannel
{
    /**
     * @var Client
     */
    private $client;
    public function __construct(Client $client)
    {
        $this->client = $client;
    }
    /**
     * Send the given notification.
     *
     * @param  mixed  $notifiable
     * @param  \Illuminate\Notifications\Notification  $notification
     * @return void
     */
    public function send($notifiable, Notification $notification)
    {
        $data = $notification->toGoogle($notifiable);
        if (empty($data['webhook'])) {
            $webhook = config('google.chat.webhook');
        } else {
            $webhook = $data['webhook'];
        }
        $headers = [
            'content-type' => 'application/json',
        ];
        $data = json_encode([
                'text' => Str::limit($data['message'], 4080, ' (...)')
                ], JSON_UNESCAPED_UNICODE);
        $request = new Request('POST', $webhook, $headers, $data);
        $response = $this->client->send($request);
        if ($response->getStatusCode() !== 200) {
            Log::error($response);
        }
    }
}
