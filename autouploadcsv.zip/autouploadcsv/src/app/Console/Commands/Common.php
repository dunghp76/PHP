<?php

namespace App\Console\Commands;

use Illuminate\Support\Facades\File;
use Laravel\Dusk\Browser;

class Common
{
	public static function download($hasRunUploadAfter)
	{
		(new DownloadCsv)->exec($hasRunUploadAfter);
	}

	public static function upload(Browser $browser)
	{
		(new UploadCsv())->exec($browser);
	}

	public static function runBatch($path)
	{
		exec("cmd.exe /c {$path}");
	}

	public static function getConfig()
	{
		// root path contains project
		$rootPath = str_replace(basename(base_path()), '', base_path());

		$ini = parse_ini_file("{$rootPath}config.ini", true);

		$ini['info']['root_path'] = $rootPath;
		// csv folder path
		$ini['info']['folder_upload_will']	= "{$rootPath}{$ini['info']['folder_upload_will']}\\";
		$ini['info']['folder_upload_ok']	= "{$rootPath}{$ini['info']['folder_upload_ok']}\\";
		$ini['info']['folder_upload_state']	= "{$rootPath}{$ini['info']['folder_upload_state']}\\";
		// log path
		$ini['info']['log_download']		= "{$rootPath}{$ini['info']['log_download']}";
		$ini['info']['log_upload']			= "{$rootPath}{$ini['info']['log_upload']}";
		// batch path
		$ini['info']['batch_upload']		= "{$rootPath}{$ini['info']['batch_upload']}";
		$ini['info']['batch_download']		= "{$rootPath}{$ini['info']['batch_download']}";

		$ini = (object)$ini['info'];

		return $ini;
	}

	public static function listFilesUploadOk($config)
	{
		return glob("{$config->folder_upload_ok}{$config->prefix_csv}*.csv");
	}

	public static function listFilesUploadWill($config)
	{
		$patternCsvPath = "{$config->folder_upload_will}{$config->prefix_csv}*.csv";
		return glob($patternCsvPath);
	}

	public static function listFilesIsUploading($config)
	{
		return glob("{$config->folder_upload_will}{$config->prefix_csv}*.csv.{$config->surfix_upload_flg}");
	}

	public static function listFilesIsDownloading($config)
	{
		return glob("{$config->folder_upload_will}{$config->prefix_csv}*.csv.{$config->surfix_download_flg}");
	}

	public static function formatLog($msg, $hasFormat = true)
	{
		return PHP_EOL . (!$hasFormat ? now() : '') . ($hasFormat ? "==> " . now() : '') . ' ' . $msg;
	}

	public static function log($path, $msg, $config)
	{
		if (empty($msg)) {
			return;
		}
		if (is_array($msg)) {
			$msg = implode(PHP_EOL, $msg);
		}
		echo $msg;
		static::logLocal($path, $msg);
		static::log2GoogleChat($config->webhook, $msg);
	}

	public static function logLocal($path, $msg)
	{
		if (empty($msg)) {
			return;
		}
		if (is_array($msg)) {
			$msg = implode(PHP_EOL, $msg);
		}
		static::createDir($path);
		File::append($path, $msg . PHP_EOL);
	}

	public static function log2GoogleChat($webhook, $message)
	{
		if (empty($webhook)) {
			$arrRe = [
				'error'     => 1,
				'message'   => 'Webhook not found !',
			];
		}

		$arrRe = [
			'error'     => 0,
			'message'   => 'Send Successfully',
		];

		if (is_array($message)) {
			$message = implode(PHP_EOL, $message);
		}

		$data = json_encode([
			'text' => $message
		], JSON_UNESCAPED_UNICODE);

		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $webhook);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
		curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_HTTPHEADER, [
			'Content-Type: application/json',
		]);

		$response = curl_exec($curl);
		$err      = curl_error($curl);

		curl_close($curl);

		if ($err) {
			$arrRe['error'] = 1;
			$arrRe['message'] = $err;
		}
		$arrRe['additional'] = $response;

		return $arrRe;
	}

	public static function createDir($path)
	{
		if (empty($path)) {
			return;
		}

		$path = dirname($path);
		if (!File::exists($path)) {
			File::makeDirectory($path);
		}
	}

	public static function createFile($path, $content = '')
	{
		if (empty($path)) {
			return;
		}
		if (!File::exists($path)) {
			static::createDir($path);
		}
		File::put($path, $content);
	}

	public static function moveFile($path, $targetPath)
	{
		static::createDir($path);
		static::createDir($targetPath);

		File::move($path, $targetPath);
	}
}
