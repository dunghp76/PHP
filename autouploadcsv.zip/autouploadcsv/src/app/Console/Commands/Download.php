<?php

namespace App\Console\Commands;

use phpseclib3\Net\SFTP;
use App\Console\Commands\Common;
use Illuminate\Support\Facades\File;
use phpseclib3\Crypt\PublicKeyLoader;

class DownloadCsv
{
	/**
	 * @param bool $hasRunUploadAfter Xác nhận có chạy upload csv ngay sau khi download.
	 */
	function exec($hasRunUploadAfter = false)
	{
		$logs[] = Common::formatLog("======================Start Downloading======================", false);

		// config
		$config = Common::getConfig();

		// file need to download
		$fileDownload = '';
		// download status
		$downloadFlg = false;
		// sftp
		$sftp = null;
		// prepare before download
		if ($this->prepare($sftp, $config, $logs, $fileDownload)) {
			// download
			if (!empty($sftp)) {
				$downloadFlg = $this->download($sftp, $config, $logs, $fileDownload);
			}
			// xóa flg file downloading
			foreach (Common::listFilesIsDownloading($config) as $file) {
				File::delete($file);
			}
			// xóa các files khác chỉ giữ lại file vừa download xong
			foreach (Common::listFilesUploadWill($config) as $file) {
				if (basename($file) != $fileDownload) {
					File::delete($file);
				}
			}
		}
		// log
		$logs[] = Common::formatLog("======================End Downloading======================", false);
		Common::log($config->log_download, $logs, $config);
		// excecute upload file to kakaku.com
		if ($hasRunUploadAfter) {
			Common::runBatch($config->batch_upload);
		}
	}

	private function connectSftp($config)
	{
		$key = PublicKeyLoader::load(file_get_contents($config->ftp_key_path));
		$sftp = new SFTP($config->ftp_host);

		if (!$sftp->login($config->ftp_username, $key)) {
			$logs[] = new \Exception('Login failed');
			$logs[] = Common::formatLog("Login failed");
			return null;
		}

		return $sftp;
	}

	private function prepare(&$sftp, $config, &$logs, &$fileDownload)
	{
		// stop download khi đang có file nào đang uploading
		foreach (Common::listFilesIsUploading($config) as $fileName) {
			$logs[] = Common::formatLog("Has file " . basename($fileName) . " is in uploading processing...Download is deined !");
			return false;
		}
		// chặn khi có file đang được downloading...
		// nhận biết = flg file dạng [CsvCompare202106041535.csv.downloading]
		foreach (Common::listFilesIsDownloading($config) as $file) {
			$logs[] = Common::formatLog("Has file " . basename($file) . " is in downlading processing...Download is deined !");
			return false;
		}

		// connect to sftp
		$sftp = $this->connectSftp($config);

		// list all remote files
		$nlistCompare = $sftp->nlist($config->remote_path_download);
		if (!$nlistCompare) {
			$logs[] = Common::formatLog("Error listing files");
			return false;
		}
		// filter get only csv file with format (CsvCompare202106031535.csv)
		$matches = preg_grep("/^{$config->prefix_csv}[0-9]+[.]csv/i", $nlistCompare);
		if (count($matches) === 0) {
			$logs[] = Common::formatLog("No file to download");
			return false;
		}
		$files = array_values($matches);
		// get latest file need to download
		$latestModTime = 0;
		foreach ($files as $filename) {
			// get latest modified time of file (microtime)
			$modTime = $sftp->filemtime("{$config->remote_path_download}{$filename}");
			if ($modTime > $latestModTime) {
				$latestModTime = $modTime;
				$fileDownload = $filename;
			}
		}

		return true;
	}

	private function download($sftp, $config, &$logs, $fileDownload)
	{
		// tạo flg file để nhận biết là file đang downloading
		$flgFileDownloading = "{$config->folder_upload_will}{$fileDownload}.{$config->surfix_download_flg}";
		Common::createFile($flgFileDownloading);
		// downloading...
		$logs[] = Common::formatLog("File {$fileDownload} is downloading...");
		$fullPathDownloadRemote = "{$config->remote_path_download}{$fileDownload}";
		$fullPathDownloadLocal = "{$config->folder_upload_will}{$fileDownload}";
		if (!$sftp->get($fullPathDownloadRemote, $fullPathDownloadLocal)) {
			$logs[] = "==> Error downloading file." . PHP_EOL;
			return false;
		}
		// trên remote: download ok => move file vừa download đến folder [uploadbk]
		// theo luồng chạy thì folder [upload_compare] chỉ chứa 1 file csv (tuần chạy 1 lần)
		$sftp->rename($fullPathDownloadRemote, "{$config->remote_path_bk}{$fileDownload}");

		// trên remote: xóa các files trong folderbk cách đây 1 tuần
		$nlistBk = $sftp->nlist($config->remote_path_bk);
		if ($nlistBk) {
			foreach ($nlistBk as $file) {
				if ($file == '..' || $file == '.' || $file == '...'
				) {
					continue;
				}
				$pathFile = "{$config->remote_path_bk}{$file}";
				$dateFile = date('Ymd', $sftp->filemtime($pathFile));
				$oldDate = date('Ymd', strtotime(now() . " -15 days"));
				if ($dateFile < $oldDate) {
					$sftp->delete($pathFile);
				}
			}
		}

		$logs[] = Common::formatLog("File {$fileDownload} has been downloaded successfully.");

		return true;
	}
}
