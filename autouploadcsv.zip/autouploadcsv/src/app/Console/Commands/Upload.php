<?php

namespace App\Console\Commands;

use Laravel\Dusk\Browser;
use App\Console\Commands\Common;
use Illuminate\Support\Facades\File;

class UploadCsv
{
	function exec(Browser $browser)
	{
		$logs[] = Common::formatLog("======================Start Uploading======================", false);
		// config
		$config = Common::getConfig();
		//
		$uploadFileName = '';
		$fullPathUploadFile = '';
		// validate
		if ($this->validate($config, $logs, $uploadFileName, $fullPathUploadFile)) {
			// upload
			$this->upload($browser, $config, $logs, $uploadFileName, $fullPathUploadFile);
		}
		// log
		$logs[] = Common::formatLog("======================End Uploading======================", false);
		Common::log($config->log_upload, $logs, $config);
	}

	private function validate($config, &$logs, &$uploadFileName, &$fullPathUploadFile)
	{
		// lấy tên file mới nhất cần upload
		$maxIndexCsv = 0;
		foreach (Common::listFilesUploadWill($config) as $fileName) {
			$indexCsv = (int)str_replace([$config->prefix_csv, ".csv"], "", basename($fileName));
			if ($indexCsv > $maxIndexCsv) {
				$maxIndexCsv = $indexCsv;
			}
		}
		// csv name to upload
		$uploadFileName = $maxIndexCsv == 0 ? '' : "{$config->prefix_csv}{$maxIndexCsv}.csv";
		// không có file hợp lệ để upload
		if (empty($uploadFileName)) {
			// file chưa upload ok và cũng không có file để upload => file chưa đươc download về
			// vì 1 tuần download file 1 lần nên check dựa theo năm tháng ngày theo tên file
			$indexFile = date('Ymd');
			$patternCsvPath = "{$config->folder_upload_ok}{$config->prefix_csv}{$indexFile}*.csv";
			if (count(glob($patternCsvPath)) === 0) {
				$logs[] = Common::formatLog("File has not been downloaded yet");
			}
			$logs[] = Common::formatLog("No file to upload");

			// tiến hành download file
			// Common::download(false);

			return false;
		}
		// nếu có file nào đang được upload mà chưa xong => ngưng chạy,
		// không cho chạy trong lúc có file đang dược upload
		foreach (Common::listFilesIsUploading($config) as $fileName) {
			$logs[] = Common::formatLog("Has file " . basename($fileName) . " is in uploading processing... Upload is denied !");
			return false;
		}
		// nếu file chưa download về xong thì không cho upload
		if(File::exists("{$config->folder_upload_will}{$uploadFileName}.{$config->surfix_download_flg}")){
			$logs[] = Common::formatLog("File " . basename($fileName) . " not downloaded yet, in downloading processing... Upload is denied !");
			return false;
		}

		// cập nhật flg uploading cho file
		Common::createFile("{$config->folder_upload_will}{$uploadFileName}.{$config->surfix_upload_flg}");
		// get full path of csv file will be upload
		$fullPathUploadFile = $config->folder_upload_will . $uploadFileName;

		return true;
	}

	private function upload(Browser $browser, $config, &$logs, &$uploadFileName, &$fullPathUploadFile)
	{
		$resultFlg = false;
		$logs[] = Common::formatLog("File CSV to upload: {$uploadFileName}");
		try {
			$browser->visit($config->kku_url)
				->assertSee('店舗様管理画面 ログイン')
				->type('login', $config->kku_user)
				->type('pswd', $config->kku_pwd)
				->click('#BtnLogin')
				// nếu thấy dòng text này nghĩa là
				// trang đang bảo trì từ (mặc định trên kakaku.com 3 -> 5AM là k được login)
				->assertDontSee('店舗様管理画面 システムメンテナンス中')
				// login ok
				->assertSee('価格更新（CSV）')
				->clickLink('価格更新（CSV）')
				->assertSee('１．CSVアップロード＆データチェック')
				->clickLink('１．CSVアップロード＆データチェック')
				// nếu thấy dòng text này nghĩa là
				// đang trong quá trình checking data csv, một lúc sau mới được upload tiếp csv
				->assertDontSee('現在行われている処理の状況を確認することができます。')
				// vào được trang upload csv
				->assertSee('１．CSVファイル アップロード＆データチェック')
				->attach('TxtCSVFile', $fullPathUploadFile)
				->type('TxtMailAddress', $config->kku_email)
				->element("[value='アップロード']")
				->click();
			// $browser->assertDialogOpened("「CSVファイル」は拡張子「.csv」のファイルを選択してください。\n「メールアドレス」を入力してください。\n")
			// confirm dialog trước khi cho upload file
			$browser->assertDialogOpened("ファイルをアップロードしてもよろしいですか？")
				// xác nhận OK
				->acceptDialog()
				// uploaded successfully
				->assertSee('１．CSVファイル アップロード＆データチェック アップロード完了');
			// ->pause(2000);

			$logs[] = Common::formatLog("Uploaded Success");

			// move uploaded csv file to [OK folder]
			$targetPath = "{$config->folder_upload_ok}{$uploadFileName}";
			Common::moveFile($fullPathUploadFile, $targetPath);

			$resultFlg = true;
		} catch (\Throwable $th) {

			$logs[] = Common::formatLog("ERROR");
			// đang trong quá trình checking data csv, một lúc sau mới được upload tiếp csv
			if (strpos($th->getMessage(), '現在行われている処理の状況を確認することができます。') > -1) {
				Common::formatLog("Page is in checking csv data processing...");
			}
			// trang kakaku.com đang trong lúc bảo trì hệ thống từ 3 -> 5AM
			if (strpos($th->getMessage(), '店舗様管理画面 システムメンテナンス中') > -1) {
				Common::formatLog("Store management screen System maintenance in progress ...");
			}
			$logs[] = Common::formatLog($th);
			$logs[] = Common::formatLog($th->getMessage());
			$logs[] = Common::formatLog("ERROR");
		}

		// xóa file nhận biết trạng thái uploading...
		foreach (Common::listFilesIsUploading($config) as $file) {
			File::delete($file);
		}

		// xóa các file đã upload thành công cách đây 2 tuần (không cần giữ quá nhiều files trong folder OK)
		foreach (Common::listFilesUploadOk($config) as $file) {
			$dateFile = date('Ymd', filemtime($file));
			$oldDate = date('Ymd', strtotime(now() . " -14 day"));
			if ($dateFile < $oldDate) {
				File::delete($file);
			}
		}

		return $resultFlg;
	}
}
