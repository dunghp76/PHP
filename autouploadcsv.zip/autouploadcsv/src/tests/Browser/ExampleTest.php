<?php

namespace Tests\Browser;

use Tests\DuskTestCase;
use Laravel\Dusk\Browser;
use App\Console\Commands\Common;
use Illuminate\Notifications\Notifiable;

class ExampleTest extends DuskTestCase
{
    use Notifiable;
    /**
     * A basic browser test example.
     *
     * @return void
     */
    public function testBasicExample()
    {
        $this->browse(function (Browser $browser) {
            Common::upload($browser);
        });
    }
}
