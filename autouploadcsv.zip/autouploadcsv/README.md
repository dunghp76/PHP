## I. Giới thiệu

### Ứng dụng này có chức năng là gì ?

Ứng dụng này dùng để tự động upload file csv chứa thông tin về so sánh giá sản phẩm lên trang kakaku.com.
Hiện tại phải upload thủ công, cứ mỗi chủ nhật phải lên trang kakaku.com và tự upload csv bằng tay.
Với file csv dùng để upload thì hiện tại là cứ vào lúc 1 giờ sáng CN là server sẽ tự sinh ra 1 file csv có kiểu file CsvCompare202106031535.csv.
Sau đó ta phải lên lấy file csv này và upload lên trang kakaku.com.

Như vậy ứng dụng auto này sẽ làm thao tác là vào chủ nhật sẽ tự động download file csv trên ftp về sau đó sẽ tự động upload file csv lên trang kakaku.com luôn.

Chức năng chính của ứng dụng là tự động truy cập vào trang kakaku.com để upload file nên ứng dụng sử dụng tính [laravel dusk] tham khảo tại:
https://laravel.com/docs/8.x/dusk
Và để truy cập SFTP download file về dùng package [phpseclib/phpseclib] tham khảo tại
https://github.com/phpseclib/phpseclib

### Luồng chạy như thế nào ?
Tại ftp `52.68.23.81` path `/var/batch/kakaku/csv/upload_compare` vào lúc `1AM Sunday` sẽ tự sinh ra file csv có format kiểu `CsvCompare202106031535.csv`. Tại máy windows set task schedule chạy file batch để tự động vào lúc `2AM Sunday` sẽ auto download file csv trên về máy local (khi file được download sẽ được move vào `/var/batch/kakaku/csv/uploadbk`) sau khi download OK thì tự động upload file csv vừa download được lên trang kakaku.com. Task schedule này sẽ được chạy repeate `2 tiếng/lần` cho hết ngày `Sunday` đó (tránh tình trạng upload 1 lần chưa được).

## II. Cài đặt

### A. Để chạy được ứng dụng cần cài những tools sau:

1. Cài Chrome
	- https://www.google.com/intl/vi/chrome/?brand=CHBD&brand=FKPE&gclid=Cj0KCQjw--GFBhDeARIsACH_kdZKbNcj9wRjx_rvsuSf1DBLsXQDNf2QsHEDqNAgYctLTk7IOliDz4QaAqKeEALw_wcB&gclsrc=aw.ds
2. Cài Composer
	https://getcomposer.org/download/
3. Cài Wampp
	- https://drive.google.com/uc?id=1ysQIoKV2Cm_50DcbcA6-oBqTfrpVS1G9&export=download
	- Lỗi dll thì theo link sau
		https://www.microsoft.com/en-us/download/details.aspx?id=30679
4. Cài Git
	- https://git-scm.com/download/win
	- https://tortoisegit.org/download/

### B. Chạy lệnh và cấu hình

Sau khi cài các tools trên ở bước A, cần chạy các lệnh và cấu hình như sau:

**B.1. Cấu hình file ini**
1. Tìm file config.example.ini -> copy ra file mới đặt tên là "config.ini"
2. Mở file config.ini mới tạo và điều chỉnh thông số sau (trong ini có nhiều thông số có thể thay đổi được nhưng để chạy ngay thì chỉ cần [key_path],[kku_email] trước là OK)
	- [ftp_key_path] : Điền đường dẫn tuyệt đối đến nơi chứa private key để connect đến sftp.
	- [kku_email]: thông tin mail sẽ nhận khi upload file OK từ kakaku.com

**B.2. Chạy lệnh trong laravel**
1. Tại terminal cd vào thư mục chứa source laravel là [src]
2. Chạy các lệnh sau:
	- composer install
	- php artisan dusk:chrome-driver --detect

OK đến đây là hoàn tất việc cấu hình và có chạy được rồi.

## III. Cấu trúc và cách chạy như thế nào ?

### A. Cấu trúc

1. Ở đây khi clone về sẽ cấu trúc cây thư mực như sau
	- batch (nới chứa các file batch để chạy chương trình)
		- run.bat (tự động download file về là tiến hành upload file lên kakaku luôn)
		- download.bat (chỉ download file từ ftp về local)
		- upload.bat (chỉ upload file lên kakaku.com)
	- src (nơi chứa source dự án)
	- config.ini (nơi cấu hình các thông số để chạy chương trình)

2. Sau khi chạy chương trình có thể ta sẽ thấy thêm một số folder sau:
	- upload_will (nơi chứa file csv cần được upload lên kakaku.com)
		- trong folder khi file nào đang đang được uploading thì nó sẽ tạo ra 1 file kiểu CsvCompare202106031535.csv.uploading để nhận biết file này đang được upload chưa xong.
	- upload_ok (chứa các files đã upload thành công, khi upload ok sẽ move file từ [upload_will] sang đây)
	- log (ghi log ứng dụng có cả push log lên google chat, có thể thay đổi kênh google chat bằng mục [webhook] trong file config.ini)
		- upload.log (log thông tin của việc upload)
		- download.log (log thông tin của việc download)

### B. Chạy chương trình như thế nào ?

***Chú ý: Chỉ cần chạy file batch không cần phải chạy wamppserver***

1. Chạy manual
	- Nếu muốn tự động download xong là upload liền thì chạy file
		-> batch/run.bat
	- Chỉ chạy download
		-> batch/download.bat
	- Chỉ chạy upload
		-> batch/upload.bat

2. Chạy tự động theo task schedule của windows

- Để upload file trước hết cần phải download file về local sau đó mới tiến hành upload file.
- Vào [Task Scheduler] trên windows và tạo ra 2 tasks sau:
	- Cài download và upload riêng biệt
		- download : set chạy vào lúc 2AM và sẽ lặp lại sau 2 tiếng và chỉ chạy trong ngày CN đó (việc chạy lặp trong ngày tránh việc không download được file khi chạy lần đầu)
		- upload: set chạy vào lúc 2:30AM và sẽ lặp lại sau 2h và chỉ chạy trong ngày CN đó (việc chạy lặp trong ngày tránh việc không upload được trong những lần trước).
	- Chỉ chạy một batch run.bat (down xong là chạy upload luôn)
		- set chạy vào lúc 2:AM và sẽ lặp lại sau 2h và chỉ chạy trong ngày CN đó (việc chạy lặp trong ngày tránh việc không upload được trong những lần trước).

***Chú ý:***
- Nếu việc tự động của download & upload có vấn đề thì có thể chuyển sang chạy tay bằng cách như đề cập ở [III.B.1]
- File csv được sinh ra vào lúc 1AM chủ nhật và có thể mất 2-3' để sinh file
- Trang kakaku định kỳ sẽ bảo trì hệ thống từ 3->5AM mỗi ngày vì vậy trong khung giờ này sẽ không login vào kakaku.com được
- Trang kakaku định kỳ sẽ tiến hành perfomed data từ 3->3:30PM mỗi ngày trong khưng giờ này cũng không upload file được.
- File sau khi được upload lên kakaku.com OK thì ngay sau đó ta sẽ không vào lại được trang upload để upload lại liền được,
	mà phải chờ tầm vài phút sau để khi upload file hệ thống của kakaku sẽ checking data vừa import .